Cushion trainer - Android Studio project
--------------------------------------
This project is a ready-to-open Android Studio project that loads a local HTML/JS trainer in a WebView.
How to build:
1. Open this folder in Android Studio (File -> Open).
2. Let Android Studio sync and download Gradle & SDK components.
3. Build -> Build APK(s).
4. Install the APK from app/build/outputs/apk/debug/app-debug.apk on your phone.
Notes:
- This project uses a WebView to render the trainer UI and logic from assets/index.html.
- If you want a CI build, ask me and I'll provide a GitHub Actions workflow (requires gradle wrapper).
